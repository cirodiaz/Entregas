C�digo y nombre del curso: Conceptos avanzados de Ingenier�a de SoftWare
Nombre de la tarea: Tarea No. 1 - PSP0
Nombre del estudiante: Ciro Andr�s D�az Rodr�guez
Fecha de env�o de la tarea: 8 de Febrero de 2017

Instrucciones para ejecutar el programa:

Prerrequisitos:

a. Asegurarse de usar la versi�n de java 1.8.0_121
b. Crear el archivo "archivoin.txt" en la carpeta "C:\tarea1" (el valor es fijo), y a�adirle l�neas con un n�mero en cada l�nea;
los n�meros son de tipo "float". Si se ingresan valores diferentes a n�meros, el programa fallar�.
c. Se asume que el usuario ha descomprimido la carpeta que contiene el directorio "src", y que ya puede acceder a su contenido.

Para hacer uso del programa de tarea 1, por favor realizar el siguiente proceso:

1. abrir la l�nea de comandos
2. navegar hacia la carpeta "src" dentro de la carpeta "Tarea 1 - ca.diazr1"
3. abrir una l�nea de comandos, navegar hasta la carpeta indicada en el punto 2 (por ejemplo: cd C:\Tarea 1 - ca.diazr1\src)
4. digitar el comando "java -jar estadisticas.jar"
5. verificar que el resultado es coherente con lo que se espera desde el archivo.



